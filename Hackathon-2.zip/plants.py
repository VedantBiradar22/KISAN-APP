from flask import Flask, request, jsonify, render_template_string
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import json
from googletrans import Translator
import base64
import os

app = Flask(__name__)

model = load_model(r'C:\Users\shobit\hackattack\plant_disease_model.h5')

with open('class_precautions.json') as f:
    class_data = json.load(f)

index_to_class = {v["id"]: k for k, v in class_data.items()}

def preprocess_image(path, target_size=(224, 224)):
    img = load_img(path, target_size=target_size)
    arr = img_to_array(img) / 255.0
    return np.expand_dims(arr, axis=0)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>🌿 Plant Disease Detector</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #121212;
      color: #e0f2f1;
      margin: 0;
      padding: 2rem;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    h2 { color: #a5d6a7; font-weight: 600; margin-bottom: 1rem; }
    .card {
      background: #1e1e1e;
      padding: 1.5rem;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      max-width: 500px;
      width: 100%;
    }
    video, canvas {
      border-radius: 12px;
      border: 3px solid #66bb6a;
      margin-bottom: 1rem;
      width: 100%;
    }
    button {
      padding: 12px 20px;
      background-color: #66bb6a;
      color: #1b1b1b;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    button:hover { background-color: #4caf50; }
    select {
      padding: 10px;
      width: 100%;
      border: 1px solid #81c784;
      border-radius: 6px;
      margin-bottom: 1rem;
      font-size: 1rem;
      background-color: #2c2c2c;
      color: #e0f2f1;
    }
    #result {
      margin-top: 20px;
      background: #263238;
      border-left: 5px solid #66bb6a;
      padding: 1rem;
      border-radius: 10px;
    }
    ul { padding-left: 1.2rem; margin-top: 0.5rem; }
  </style>
</head>
<body>
  <h2 id="title">🌿 Plant Disease Detector</h2>
  <div class="card">
    <video id="video" autoplay></video>
    <canvas id="canvas" width="300" height="225" style="display:none;"></canvas>

    <label for="lang" id="langLabel">Choose Language:</label>
    <select id="lang" onchange="updateUIText(this.value)">
      <option value="en">English</option>
      <option value="hi">हिंदी</option>
      <option value="te">తెలుగు</option>
    </select>

    <button id="captureBtn" onclick="capture()">Capture & Predict</button>
    <div id="result"></div>
  </div>

  <script>
    const LANGUAGES = {
      en: {
        title: "🌿 Plant Disease Detector",
        capture: "Capture & Predict",
        chooseLanguage: "Choose Language:",
        prediction: "Prediction",
        original: "Original",
        translated: "Translated",
        language: "Language",
        precautions: "Precautions"
      },
      hi: {
        title: "🌿 पौधों के रोग पहचानें",
        capture: "कैप्चर करें और पहचानें",
        chooseLanguage: "भाषा चुनें:",
        prediction: "पूर्वानुमान",
        original: "मूल",
        translated: "अनुवादित",
        language: "भाषा",
        precautions: "सावधानियाँ"
      },
      te: {
        title: "🌿 మొక్కల వ్యాధి గుర్తింపు",
        capture: "ఫోటో తీసి గుర్తించండి",
        chooseLanguage: "భాషను ఎంచుకోండి:",
        prediction: "ఫలితం",
        original: "అసలు",
        translated: "అనువాదం",
        language: "భాష",
        precautions: "జాగ్రత్తలు"
      }
    };

    function updateUIText(lang) {
      const text = LANGUAGES[lang] || LANGUAGES.en;
      document.getElementById("title").textContent = text.title;
      document.getElementById("langLabel").textContent = text.chooseLanguage;
      document.getElementById("captureBtn").textContent = text.capture;
    }

    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    function isMobile() {
      return /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    }

    function startCamera() {
      const constraints = isMobile()
        ? { video: { facingMode: "environment" } }
        : { video: true };

      navigator.mediaDevices.getUserMedia(constraints)
        .then(stream => video.srcObject = stream)
        .catch(err => console.warn("Camera error:", err));
    }

    function capture() {
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataURL = canvas.toDataURL('image/jpeg');
      const lang = document.getElementById('lang').value;

      fetch('/predict_camera', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: dataURL, lang: lang })
      })
      .then(res => res.json())
      .then(data => {
        const text = LANGUAGES[lang] || LANGUAGES.en;
        const precautions = data.precautions.map(p => `<li>${p}</li>`).join('');
        document.getElementById('result').innerHTML = `
          <h3>${text.prediction}</h3>
          <p><b>${text.original}:</b> ${data.original_prediction}</p>
          <p><b>${text.translated}:</b> ${data.translated_prediction}</p>
          <p><b>${text.language}:</b> ${data.language}</p>
          <h4>${text.precautions}:</h4>
          <ul>${precautions}</ul>
        `;
      });
    }

    startCamera();
    updateUIText("en"); // default on load
  </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/predict_camera', methods=['POST'])
def predict_camera():
    data = request.get_json()
    image_data = data['image'].split(',')[1]
    lang = data.get('lang', 'en')

    temp_path = 'temp.jpg'
    with open(temp_path, 'wb') as f:
        f.write(base64.b64decode(image_data))

    img_batch = preprocess_image(temp_path)
    preds = model.predict(img_batch)
    predicted_index = preds.argmax(axis=-1)[0]
    predicted_class = index_to_class[predicted_index]

    precautions = class_data.get(predicted_class, {}).get("precautions", ["No specific precautions available."])
    translated = predicted_class
    translator = Translator()
    supported_languages = ['hi', 'te']

    try:
        if lang in supported_languages:
            translated = translator.translate(predicted_class, dest=lang).text
            precautions = [translator.translate(p, dest=lang).text for p in precautions]
    except Exception as e:
        print("Translation error:", e)

    if os.path.exists(temp_path):
        os.remove(temp_path)

    return jsonify({
        'original_prediction': predicted_class,
        'translated_prediction': translated,
        'language': lang,
        'precautions': precautions
    })

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, ssl_context=('cert.pem', 'key.pem'))
